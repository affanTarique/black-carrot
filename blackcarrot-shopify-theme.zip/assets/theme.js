document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-add-to-cart]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const id=btn.dataset.addToCart;
      const qty=Number(btn.dataset.qty||1);
      try{
        const r=await fetch('/cart/add.js',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:[{id,quantity:qty}]})});
        if(!r.ok) throw new Error();
        const t=document.getElementById('toast'); t.textContent='Added to cart'; t.style.display='block';
        setTimeout(()=>t.style.display='none',1800);
      }catch(e){window.location.href='/cart';}
    });
  });
});
