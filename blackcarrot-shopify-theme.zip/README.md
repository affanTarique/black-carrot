# BlackCarrot-inspired Shopify Theme

This is an original Shopify Online Store 2.0 theme built from scratch to reproduce the visible structure and visual direction of the BlackCarrot storefront:
- black announcement strip
- centered black/orange wordmark
- multi-category navigation
- large ceramics hero
- Why Choose Us cards
- Best Sellers grid
- gifting feature block
- Home & Kitchen categories
- news/about/footer sections
- collection, product, cart and search templates
- responsive mobile styling

Important:
- Product images in this demo are original SVG illustrations, not copied website assets.
- Add your Shopify products and collections after uploading; the theme automatically uses Shopify product images where available.
- This is not the original BlackCarrot theme/code.
